import sys
import os

print("Verifying Environment...")

try:
    import torch
    print(f"Torch Version: {torch.__version__}, CUDA: {torch.cuda.is_available()}")
except ImportError:
    print("ERROR: torch not found.")
    sys.exit(1)

try:
    import monai
    print(f"MONAI Version: {monai.__version__}")
except ImportError:
    print("ERROR: monai not found.")
    sys.exit(1)

try:
    import nibabel
    print(f"Nibabel Version: {nibabel.__version__}")
except ImportError:
    print("ERROR: nibabel not found.")
    sys.exit(1)

try:
    import SimpleITK
    print(f"SimpleITK Version: {SimpleITK.__version__}")
except ImportError:
    print("ERROR: SimpleITK not found.")
    sys.exit(1)

# Check Paths
print("Checking Paths...")
cwd = os.getcwd()
print(f"Current Directory: {cwd}")

if not os.path.exists("configs/config.yaml"):
    print("ERROR: configs/config.yaml not found!")
    sys.exit(1)

if not os.path.exists("src"):
    print("ERROR: src directory not found!")
    sys.exit(1)

print("\nEnvironment Verified. Ready to run.")
