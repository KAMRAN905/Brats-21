import random
import sys

# Robust Monkeypatch for Windows random.seed OverflowError
import traceback
original_seed = random.seed
def safe_seed(a=None, version=2):
    try:
        if a is not None:
             if isinstance(a, int):
                # Clamp to 31-bit signed integer range (0 to 2^31-1)
                a = a & 0x7FFFFFFF
        original_seed(a, version)
    except Exception as e:
        # If it still fails, use a safe constant
        original_seed(42, version)
random.seed = safe_seed

# MONAI-Specific Monkeypatch for Windows
try:
    import monai.transforms.transform
    # The error reported is in set_random_state: "_seed = _seed % MAX_SEED"
    # We patch this method to ensure seed is always safe before that line.
    
    _orig_set_rs = monai.transforms.transform.Randomizable.set_random_state
    
    def safe_set_random_state(self, seed=None, state=None):
        if seed is not None:
            try:
                # Aggressively clamp to 31-bit for Windows
                seed = int(seed) & 0x7FFFFFFF
            except:
                seed = 42
        _orig_set_rs(self, seed, state)

    monai.transforms.transform.Randomizable.set_random_state = safe_set_random_state
    # print("MONAI random_state patched for Windows safety.")
except Exception as e:
    print(f"Could not patch MONAI: {e}")


import argparse
import os
import yaml
import torch
from torch.utils.tensorboard import SummaryWriter
from monai.losses import DiceFocalLoss
from monai.metrics import DiceMetric, HausdorffDistanceMetric
from monai.utils import set_determinism
from monai.inferers import sliding_window_inference
from monai.data import decollate_batch

from src.utils import setup_logger, set_seed, save_checkpoint
from src.dataset import get_dataloaders
from src.models import HybridSwinUNETR
from tqdm import tqdm

def train(args):
    # Load Config
    with open(args.config, 'r') as f:
        cfg = yaml.safe_load(f)
        
    # Setup
    log_dir = os.path.join(cfg['logging']['log_dir'], cfg['project']['name'])
    output_dir = os.path.join(cfg['logging']['save_dir'], cfg['project']['name'])
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)
    
    logger = setup_logger(output_dir)
    set_seed(cfg['project']['seed'])
    # set_determinism(seed=cfg['project']['seed']) # Potential OverflowError on Windows?
    
    logger.info(f"Config: {cfg}")
    
    # Data
    train_loader, val_loader, test_files = get_dataloaders(cfg['data']['root_dir'], cfg)
    logger.info(f"Train batches: {len(train_loader)}, Val batches: {len(val_loader)}")
    
    # Model
    device_str = cfg['project']['device']
    if device_str == 'cuda' and not torch.cuda.is_available():
        logger.warning("CUDA not available, switching to CPU")
        device_str = 'cpu'
    device = torch.device(device_str)
    
    model_name = cfg['model']['name']
    if model_name == 'SwinUNETR':
        from monai.networks.nets import SwinUNETR
        model = SwinUNETR(
            img_size=tuple(cfg['data']['roi_size']),
            in_channels=cfg['model']['in_channels'],
            out_channels=cfg['model']['out_channels'],
            feature_size=cfg['model']['feature_size'],
            spatial_dims=3
        )
    elif model_name == 'UNet':
        from monai.networks.nets import UNet
        model = UNet(
            spatial_dims=3,
            in_channels=cfg['model']['in_channels'],
            out_channels=cfg['model']['out_channels'],
            channels=(16, 32, 64, 128, 256),
            strides=(2, 2, 2, 2)
        )
    else:
        # Default to Hybrid
        model = HybridSwinUNETR(
            img_size=tuple(cfg['data']['roi_size']),
            in_channels=cfg['model']['in_channels'],
            out_channels=cfg['model']['out_channels'],
            feature_size=cfg['model']['feature_size'],
            use_dual_attention=cfg['model']['use_dual_attention'],
            use_fusion=cfg['model']['use_fusion'],
            fusion_type=cfg['model']['fusion_type']
        )
    
    model = model.to(device)
    
    # Loss
    loss_config = cfg['training']['loss']
    
    # We use independent Dice and Focal Losses and combine them
    # to ensure class weighting is handled correctly and robustly.
    from monai.losses import DiceLoss, FocalLoss
    
    dice_loss_func = DiceLoss(
        softmax=True,
        to_onehot_y=True,
        include_background=False
    )
    
    # Focal Loss (Supports weight in MONAI > 1.0)
    # Check if weights are provided
    focal_weights = loss_config.get('focal_weight', None)
    if focal_weights:
        if isinstance(focal_weights, list):
             focal_weights = torch.tensor(focal_weights).to(device)
    
    focal_loss_func = FocalLoss(
        to_onehot_y=True,
        weight=focal_weights,
        gamma=2.0
    )
    
    # Combined Loss Wrapper
    def criterion(pred, target):
        loss_d = dice_loss_func(pred, target)
        loss_f = focal_loss_func(pred, target)
        # Weights for combination
        ld = loss_config.get('lambda_dice', 1.0)
        lf = loss_config.get('lambda_focal', 1.0)
        return ld * loss_d + lf * loss_f
    
    loss_function = criterion
    
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(cfg['training']['lr']), weight_decay=float(cfg['training']['weight_decay']))
    
    # Scheduler
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=cfg['training']['max_epochs'])
    
    # Metrics
    dice_metric = DiceMetric(include_background=False, reduction="mean", get_not_nans=False)
    
    # Training Loop
    best_metric = -1
    best_metric_epoch = -1
    writer = SummaryWriter(log_dir=log_dir)
    
    train_history = []
    
    scaler = torch.cuda.amp.GradScaler() if cfg['training']['amp'] else None
    
    # Early Stopping
    patience = 20 # Standard patience
    no_improve_epochs = 0
    
    for epoch in range(1, cfg['training']['max_epochs'] + 1):
        model.train()
        epoch_loss = 0
        step = 0
        
        for batch_data in tqdm(train_loader, desc=f"Epoch {epoch}"):
            step += 1
            inputs, labels = batch_data["image"].to(device), batch_data["label"].to(device)
            # Handle list of crops: [B, N, C, D, H, W] -> [B*N, C, ...]
            if inputs.dim() == 6:
                inputs = inputs.view(-1, *inputs.shape[2:])
                labels = labels.view(-1, *labels.shape[2:])
            
            optimizer.zero_grad()
            
            with torch.cuda.amp.autocast(enabled=cfg['training']['amp']):
                outputs = model(inputs)
                loss = loss_function(outputs, labels)
            
            if scaler:
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
            else:
                loss.backward()
                optimizer.step()
                
            epoch_loss += loss.item()
            
        epoch_loss /= step
        logger.info(f"Epoch {epoch} loss: {epoch_loss:.4f}")
        writer.add_scalar("train/loss", epoch_loss, epoch)
        
        scheduler.step()
        
        current_val_metric = 0.0
        
        # Validation
        if epoch % cfg['training']['check_val_every_n_epoch'] == 0:
            model.eval()
            with torch.no_grad():
                for val_data in val_loader:
                    val_inputs, val_labels = val_data["image"].to(device), val_data["label"].to(device)
                    roi_size = tuple(cfg['data']['roi_size'])
                    sw_batch_size = 4
                    
                    with torch.cuda.amp.autocast(enabled=cfg['training']['amp']):
                        val_outputs = sliding_window_inference(val_inputs, roi_size, sw_batch_size, model)
                    
                    val_outputs = [decollate_batch(val_outputs)]
                    val_labels_list = [decollate_batch(val_labels)]
                    
                    preds = torch.argmax(val_outputs[0][0], dim=0, keepdim=True) # [1, D, H, W]
                    target = val_labels[0][0] # [1, D, H, W]
                    
                    y_pred_oh = torch.nn.functional.one_hot(preds.squeeze().long(), num_classes=4).permute(3, 0, 1, 2).unsqueeze(0)
                    y_oh = torch.nn.functional.one_hot(target.squeeze().long(), num_classes=4).permute(3, 0, 1, 2).unsqueeze(0)
                    
                    dice_metric(y_pred=y_pred_oh, y=y_oh)
            
            # Aggregate
            metric = dice_metric.aggregate().item()
            current_val_metric = metric
            dice_metric.reset()
            logger.info(f"Epoch {epoch} Mean Class Dice: {metric:.4f}")
            writer.add_scalar("val/mean_dice", metric, epoch)
            
            if metric > best_metric:
                best_metric = metric
                best_metric_epoch = epoch
                save_checkpoint(model, optimizer, epoch, os.path.join(output_dir, "best_model.pth"))
                logger.info("Saved new best model.")
                no_improve_epochs = 0
            else:
                no_improve_epochs += 1
                
        save_checkpoint(model, optimizer, epoch, os.path.join(output_dir, "last_model.pth"))
        
        # Log to History
        import pandas as pd
        train_history.append({
            "epoch": epoch,
            "loss": epoch_loss,
            "val_mean_dice": current_val_metric,
            "lr": optimizer.param_groups[0]['lr']
        })
        pd.DataFrame(train_history).to_csv(os.path.join(output_dir, "train_log.csv"), index=False)

        # Early Stopping Check
        if no_improve_epochs >= patience:
            logger.info(f"No improvement for {patience} epochs. Early stopping...")
            break

    logger.info(f"Training Completed. Best Metric: {best_metric} at Epoch {best_metric_epoch}")
    writer.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    args = parser.parse_args()
    train(args)
