import logging
import os
import random
import numpy as np
import torch
import sys

# Monkeypatch random.seed for Windows OverflowError
original_seed = random.seed
def safe_seed(a=None, version=2):
    try:
        if a is not None:
             # Mask to 32-bit
             if isinstance(a, int):
                a = a & 0xFFFFFFFF
        # original_seed(a, version) # Disable random.seed completely
    except Exception as e:
        # Fallback
        # original_seed(None, version)
        pass
# random.seed = safe_seed # Disable patch in utils

def setup_logger(log_dir):
    os.makedirs(log_dir, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(os.path.join(log_dir, "train.log")),
            logging.StreamHandler(sys.stdout)
        ]
    )
    return logging.getLogger("BraTS")

def set_seed(seed=42):
    # random.seed(seed) # Disabled to prevent Windows OverflowError
    
    try:
        if seed is not None:
            seed = int(seed)
            seed = seed & 0x7FFFFFFF # Ensure 31-bit signed for Windows safety
    except:
        seed = 42

    np.random.seed(seed)
    torch.manual_seed(seed)
    try:
        torch.cuda.manual_seed(seed)
    except:
        pass # No cuda
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def save_checkpoint(model, optimizer, epoch, filename):
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
    }, filename)
