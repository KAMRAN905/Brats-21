import os
import glob
from sklearn.model_selection import KFold, train_test_split
from monai.data import CacheDataset, DataLoader
from src.transforms import get_train_transforms, get_val_transforms

def get_brats_data(data_dir, test_size=0.1, val_size=0.1, seed=42, split_dir="splits"):
    # Scan for cases anywhere inside the training directory
    flair_paths = sorted(glob.glob(os.path.join(data_dir, "**", "*_flair.nii.gz"), recursive=True))
    
    # Map ID to files
    case_dict = {}
    for flair_path in flair_paths:
        base = flair_path.replace("_flair.nii.gz", "")
        case_id = os.path.basename(base)
        
        t1 = base + "_t1.nii.gz"
        t1ce = base + "_t1ce.nii.gz"
        t2 = base + "_t2.nii.gz"
        seg = base + "_seg.nii.gz"
        
        if os.path.exists(t1) and os.path.exists(t1ce) and os.path.exists(t2) and os.path.exists(seg):
            case_dict[case_id] = {
                "image": [t1, t1ce, t2, flair_path],
                "label": seg,
                "id": case_id
            }
            
    all_ids = sorted(list(case_dict.keys()))
    
    # Check if splits exist
    os.makedirs(split_dir, exist_ok=True)
    train_split_path = os.path.join(split_dir, "train_ids.txt")
    val_split_path = os.path.join(split_dir, "val_ids.txt")
    test_split_path = os.path.join(split_dir, "test_ids.txt")
    
    if os.path.exists(train_split_path) and os.path.exists(val_split_path) and os.path.exists(test_split_path):
        print(f"Loading splits from {split_dir}")
        with open(train_split_path, 'r') as f: train_ids = [line.strip() for line in f.readlines()]
        with open(val_split_path, 'r') as f: val_ids = [line.strip() for line in f.readlines()]
        with open(test_split_path, 'r') as f: test_ids = [line.strip() for line in f.readlines()]
    else:
        print(f"Creating new splits (Seed={seed})")
        if len(all_ids) < 5:
             # Demo fallback
             train_ids = all_ids[:1]
             val_ids = all_ids[-1:]
             test_ids = all_ids[-1:]
        else:
            train_val_ids, test_ids = train_test_split(all_ids, test_size=test_size, random_state=seed)
            train_ids, val_ids = train_test_split(train_val_ids, test_size=val_size / (1 - test_size), random_state=seed)
            
        # Save splits
        with open(train_split_path, 'w') as f: f.write('\n'.join(train_ids))
        with open(val_split_path, 'w') as f: f.write('\n'.join(val_ids))
        with open(test_split_path, 'w') as f: f.write('\n'.join(test_ids))
        print(f"Saved splits to {split_dir}")

    # Build lists
    train = [case_dict[cid] for cid in train_ids if cid in case_dict]
    val = [case_dict[cid] for cid in val_ids if cid in case_dict]
    test = [case_dict[cid] for cid in test_ids if cid in case_dict]
    
    return train, val, test

def get_dataloaders(data_dir, config):
    train_files, val_files, test_files = get_brats_data(
        data_dir, 
        test_size=config['data']['test_split'], 
        val_size=config['data']['val_split'],
        seed=config['project']['seed']
    )
    
    from monai.data import Dataset
    print("Creating Train Dataset...")
    # train_ds = CacheDataset(
    #     data=train_files, 
    #     transform=get_train_transforms(roi_size=tuple(config['data']['roi_size'])),
    #     cache_rate=config['data']['cache_rate'], 
    #     num_workers=int(config['data']['num_workers'])
    # )
    train_ds = Dataset(
        data=train_files, 
        transform=get_train_transforms(roi_size=tuple(config['data']['roi_size']))
    )
    
    print("Creating Val Dataset...")
    # val_ds = CacheDataset(
    #     data=val_files, 
    #     transform=get_val_transforms(), 
    #     cache_rate=config['data']['cache_rate'], 
    #     num_workers=int(config['data']['num_workers'])
    # )
    val_ds = Dataset(
         data=val_files, 
         transform=get_val_transforms()
    )
    
    # Check batch size
    bs = config['data']['batch_size']
    
    train_loader = DataLoader(train_ds, batch_size=bs, shuffle=True, num_workers=0) # pin_memory disabled for safety on windows if needed
    val_loader = DataLoader(val_ds, batch_size=1, shuffle=False, num_workers=0)
    
    return train_loader, val_loader, test_files

