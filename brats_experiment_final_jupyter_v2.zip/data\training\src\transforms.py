from monai.transforms import (
    Compose,
    LoadImaged,
    EnsureChannelFirstd,
    Orientationd,
    Spacingd,
    ScaleIntensityRanged,
    CropForegroundd,
    RandCropByPosNegLabeld,
    RandFlipd,
    RandRotate90d,
    RandShiftIntensityd,
    RandScaleIntensityd,
    RandGaussianNoised,
    RandAdjustContrastd,
    EnsureTyped,
    MapLabelValued,
    NormalizeIntensityd
)
import torch
import numpy as np
import SimpleITK as sitk
from monai.transforms import MapTransform

class N4BiasCorrectiond(MapTransform):
    def __init__(self, keys, mask_key=None, allow_missing_keys=False):
        super().__init__(keys, allow_missing_keys)
        self.mask_key = mask_key

    def __call__(self, data):
        d = dict(data)
        for key in self.key_iterator(d):
            img = d[key]
            # Handle Monai MetaTensor
            if isinstance(img, torch.Tensor):
                img_np = img.cpu().detach().numpy()
            else:
                img_np = img
            
            # [C, D, H, W]
            corrected_channels = []
            for c in range(img_np.shape[0]):
                single_chan = img_np[c]
                sitk_img = sitk.GetImageFromArray(single_chan)
                
                # Simple mask
                mask_img = sitk.OtsuThreshold(sitk_img, 0, 1, 200)
                
                try:
                    corrector = sitk.N4BiasFieldCorrectionImageFilter()
                    corrector.SetMaximumNumberOfIterations([50]*3) # Reduced optimized
                    c_img = corrector.Execute(sitk_img, mask_img)
                    corrected_channels.append(sitk.GetArrayFromImage(c_img))
                except:
                    # Fallback
                    corrected_channels.append(single_chan)
            
            corrected_stack = np.stack(corrected_channels, axis=0)
            
            # Update preserving type if possible, or just replace
            if isinstance(img, torch.Tensor):
                # If MetaTensor, we want to keep metadata, but content changes
                # Re-wrapping might be complex. 
                # For now returning tensor is fine for downstream.
                d[key] = torch.from_numpy(corrected_stack).to(img.device)
            else:
                d[key] = corrected_stack
        return d

def get_train_transforms(roi_size=(128, 128, 128)):
    return Compose([
        LoadImaged(keys=["image", "label"]),
        EnsureChannelFirstd(keys=["image", "label"]),
        MapLabelValued(keys=["label"], orig_labels=[0, 1, 2, 4], target_labels=[0, 1, 2, 3]),
        
        Orientationd(keys=["image", "label"], axcodes="RAS"),
        Spacingd(keys=["image", "label"], pixdim=(1.0, 1.0, 1.0), mode=("bilinear", "nearest")),
        
        # N4 Bias Correction
        N4BiasCorrectiond(keys=["image"]),
        # Commented out by default due to speed, uncomment if needed for high quality
        
        NormalizeIntensityd(keys=["image"], nonzero=True, channel_wise=True),
        
        # Augmentation
        RandCropByPosNegLabeld(
            keys=["image", "label"],
            label_key="label",
            spatial_size=roi_size,
            pos=1,
            neg=1,
            num_samples=2, 
            image_key="image",
            image_threshold=0,
        ),
        RandFlipd(keys=["image", "label"], prob=0.5, spatial_axis=0),
        RandFlipd(keys=["image", "label"], prob=0.5, spatial_axis=1),
        RandFlipd(keys=["image", "label"], prob=0.5, spatial_axis=2),
        RandRotate90d(keys=["image", "label"], prob=0.5, max_k=3),
        
        RandShiftIntensityd(keys=["image"], offsets=0.10, prob=0.5),
        RandScaleIntensityd(keys=["image"], factors=0.1, prob=0.5),
        RandGaussianNoised(keys=["image"], prob=0.1, mean=0.0, std=0.1),
        RandAdjustContrastd(keys=["image"], gamma=(0.5, 1.5), prob=0.3),
        
        EnsureTyped(keys=["image", "label"]),
    ])

def get_val_transforms():
    return Compose([
        LoadImaged(keys=["image", "label"]),
        EnsureChannelFirstd(keys=["image", "label"]),
        MapLabelValued(keys=["label"], orig_labels=[0, 1, 2, 4], target_labels=[0, 1, 2, 3]),
        Orientationd(keys=["image", "label"], axcodes="RAS"),
        Spacingd(keys=["image", "label"], pixdim=(1.0, 1.0, 1.0), mode=("bilinear", "nearest")),
        NormalizeIntensityd(keys=["image"], nonzero=True, channel_wise=True),
        EnsureTyped(keys=["image", "label"]),
    ])
