import os
import yaml
import subprocess
import copy
import sys

BASE_CONFIG_PATH = "configs/config.yaml"

EXPERIMENTS = [
    {
        "id": "E1_UNet_Baseline",
        "overrides": {
            "model": {"name": "UNet"}
        }
    },
    {
        "id": "E2_SwinUNETR_Baseline",
        "overrides": {
            "model": {"name": "SwinUNETR"}
        }
    },
    {
        "id": "E3_Proposed_Full",
        "overrides": {
            "model": {
                "name": "HybridSwinUNETR",
                "use_dual_attention": True, 
                "use_fusion": True
            }
        }
    },
    {
        "id": "E4_Ablation_NoDA",
        "overrides": {
            "model": {
                "name": "HybridSwinUNETR",
                "use_dual_attention": False, 
                "use_fusion": True
            }
        }
    },
    {
        "id": "E5_Ablation_NoFusion",
        "overrides": {
            "model": {
                "name": "HybridSwinUNETR",
                "use_dual_attention": True, 
                "use_fusion": False
            }
        }
    }
]

def deep_update(source, overrides):
    for key, value in overrides.items():
        if isinstance(value, dict) and value:
            returned = deep_update(source.get(key, {}), value)
            source[key] = returned
        else:
            source[key] = overrides[key]
    return source

def run_experiments():
    # Load base
    with open(BASE_CONFIG_PATH, 'r') as f:
        base_config = yaml.safe_load(f)
        
    os.makedirs("configs/generated", exist_ok=True)
    
    for exp in EXPERIMENTS:
        exp_id = exp["id"]
        print(f"--- Setting up {exp_id} ---")
        
        # Merge
        cfg = copy.deepcopy(base_config)
        cfg = deep_update(cfg, exp['overrides'])
        
        # Update output name
        cfg['project']['name'] = exp_id
        
        # Save temp config
        exp_config_path = f"configs/generated/{exp_id}.yaml"
        with open(exp_config_path, 'w') as f:
            yaml.dump(cfg, f)
            
        # Run Train
        print(f"Running Training for {exp_id}...")
        cmd = [sys.executable, "-m", "src.train", "--config", exp_config_path]
        ret = subprocess.call(cmd)
        if ret != 0:
            print(f"Error in {exp_id} training.")
            continue
            
        # Run Eval
        print(f"Running Evaluation for {exp_id}...")
        cmd_eval = [sys.executable, "-m", "src.evaluate", "--config", exp_config_path]
        subprocess.call(cmd_eval)
        
    print("All experiments completed.")
    
    # Plot results
    print("Generating Plots...")
    ret = subprocess.call([sys.executable, "scripts/plot_results.py"])
    if ret == 0:
        print("Plots generated successfully.")
    else:
        print("Error generating plots.")

if __name__ == "__main__":
    run_experiments()
