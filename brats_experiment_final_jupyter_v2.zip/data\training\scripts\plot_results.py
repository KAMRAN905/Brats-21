import os
import pandas as pd
import matplotlib.pyplot as plt
import glob
import seaborn as sns

def plot_results(output_root="outputs"):
    # Find all results.csv
    # Structure: output_root / ExperimentName / results.csv
    
    files = glob.glob(os.path.join(output_root, "*", "results.csv"))
    
    if not files:
        print("No results.csv files found to plot.")
        return
        
    dfs = []
    
    for f in files:
        exp_name = os.path.basename(os.path.dirname(f))
        df = pd.read_csv(f)
        df['Experiment'] = exp_name
        dfs.append(df)
        
    all_data = pd.concat(dfs, ignore_index=True)
    
    # Metrics to plot
    metrics = ["Dice_WT", "Dice_TC", "Dice_ET"]
    if "HD95_WT" in all_data.columns:
        metrics += ["HD95_WT", "HD95_TC", "HD95_ET"]
    
    # Plot
    # 1. Dice Comparison
    dice_cols = [m for m in metrics if "Dice" in m]
    
    # Melt for seaborn
    melted = all_data.melt(id_vars=["Experiment"], value_vars=dice_cols, var_name="Metric", value_name="Score")
    
    plt.figure(figsize=(12, 6))
    sns.boxplot(data=melted, x="Metric", y="Score", hue="Experiment")
    plt.title("Dice Score Comparison")
    plt.ylim(0, 1.0)
    plt.grid(True, alpha=0.3)
    plt.savefig(os.path.join(output_root, "ablation_dice_comparison.png"))
    print(f"Saved Dice comparison to {os.path.join(output_root, 'ablation_dice_comparison.png')}")
    
    # 2. HD95 Comparison
    hd_cols = [m for m in metrics if "HD95" in m]
    if hd_cols:
        melted_hd = all_data.melt(id_vars=["Experiment"], value_vars=hd_cols, var_name="Metric", value_name="HD95 (mm)")
        plt.figure(figsize=(12, 6))
        sns.boxplot(data=melted_hd, x="Metric", y="HD95 (mm)", hue="Experiment")
        plt.title("HD95 Comparison (Lower is Better)")
        plt.grid(True, alpha=0.3)
        plt.savefig(os.path.join(output_root, "ablation_hd95_comparison.png"))
        print(f"Saved HD95 comparison to {os.path.join(output_root, 'ablation_hd95_comparison.png')}")

if __name__ == "__main__":
    plot_results()
