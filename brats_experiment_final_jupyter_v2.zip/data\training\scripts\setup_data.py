import os
import tarfile
import shutil

# Get the directory where this script is located (scripts/)
scripts_dir = os.path.dirname(os.path.abspath(__file__))
# exp_root is the parent of scripts/ (brats_experiment/)
exp_root = os.path.dirname(scripts_dir)
# project_root is the parent of exp_root (project/)
project_root = os.path.dirname(exp_root)

data_dir = os.path.join(exp_root, "data", "training")

os.makedirs(data_dir, exist_ok=True)

import glob

# ... (imports and path setup remain)

# Ensure data directory exists
os.makedirs(data_dir, exist_ok=True)

# Find all tar and zip files in the project root or experiment root
tar_files = glob.glob(os.path.join(project_root, "*.tar")) + glob.glob(os.path.join(exp_root, "*.tar"))
zip_files = glob.glob(os.path.join(project_root, "*.zip")) + glob.glob(os.path.join(exp_root, "*.zip"))
all_data_files = tar_files + zip_files

print(f"Found {len(all_data_files)} dataset files (*.tar, *.zip) in search paths.")

import zipfile

for src in all_data_files:
    tf = os.path.basename(src)
    try:
        print(f"Extracting {tf} to {data_dir}...")
        if tf.lower().endswith(".zip"):
            with zipfile.ZipFile(src, "r") as zip_ref:
                zip_ref.extractall(data_dir)
            print(f"Extracted {tf}")
        else:
            with tarfile.open(src, "r") as tar:
                tar.extractall(path=data_dir)
            print(f"Extracted {tf}")
    except Exception as e:
        print(f"Failed to extract {tf}: {e}")

# Verify extraction
print("Contents of training dir:")
for root, dirs, files in os.walk(data_dir):
    level = root.replace(data_dir, '').count(os.sep)
    indent = ' ' * 4 * (level)
    print(f"{indent}{os.path.basename(root)}/")
    subindent = ' ' * 4 * (level + 1)
    for f in files:
        print(f"{subindent}{f}")
