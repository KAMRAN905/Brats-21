# BraTS 2021 3D Segmentation Project

This project implements a 3D medical image segmentation pipeline for the BraTS 2021 dataset using MONAI and PyTorch. It features a Hybrid SwinUNETR model with Dual Attention and Fusion modules.

## Project Structure

- `configs/`: Configuration files (YAML).
- `data/`: Data storage (place your BraTS `.tar` files in the project root to be extracted here).
- `outputs/`: Trained models, logs, and result plots.
- `scripts/`: Python scripts for data setup, experiments, and plotting.
- `src/`: Source code for dataset, model, training, and evaluation.
- `RUN_EVERYTHING.bat`: One-click execution script for Windows.

## Prerequisites

- Windows 10/11
- Python 3.8+ installed and added to PATH.
- CUDA-capable GPU (Recommended) or CPU (Slow).
- BraTS 2021 Dataset (tar files) placed in this folder.

## How to Run (Client Instructions)

1. **Place Data**: Ensure your BraTS 2021 training data `.tar` file (e.g., `BraTS2021_Training_Data.tar`) is located in this main folder (same folder as `RUN_EVERYTHING.bat`).
2. **Double-click `RUN_EVERYTHING.bat`**:
   - This script will automatically:
     - Check for Python.
     - Install all required libraries (`requirements.txt`).
     - Extract the dataset to `data/training`.
     - Run the full suite of experiments (Baselines + Proposed Methods + Ablations).
     - Generate comparison plots and summary tables in `outputs/`.
3. **Wait**: The process will take time depending on your hardware.
4. **View Results**:
   - Go to `outputs/` folder.
   - Check `ablation_dice_comparison.png` for performance comparison.
   - Individual experiment logs and best models are in subfolders (e.g., `outputs/E3_Proposed_Full/`).

## Configuration

To adjust training parameters (e.g., max_epochs, batch_size):
- Edit `configs/config.yaml`.
- Default `max_epochs` is set to 100 for full training. To run a quick test, reduce this value to 1.

## Experiments Included

- **E1**: U-Net Baseline
- **E2**: SwinUNETR Baseline
- **E3**: Proposed (Hybrid SwinUnetR + Dual Attention + Fusion)
- **E4**: Ablation (No Dual Attention)
- **E5**: Ablation (No Fusion)
