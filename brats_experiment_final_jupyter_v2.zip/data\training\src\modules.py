import torch
import torch.nn as nn
import torch.nn.functional as F

class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool3d(1)
        self.max_pool = nn.AdaptiveMaxPool3d(1)
           
        self.fc = nn.Sequential(nn.Conv3d(in_planes, in_planes // 16, 1, bias=False),
                               nn.ReLU(),
                               nn.Conv3d(in_planes // 16, in_planes, 1, bias=False))
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return x * self.sigmoid(out)

class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv3d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x_out = torch.cat([avg_out, max_out], dim=1)
        x_out = self.conv1(x_out)
        return x * self.sigmoid(x_out)

class DualAttentionModule(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.ca = ChannelAttention(channels)
        self.sa = SpatialAttention()

    def forward(self, x):
        x = self.ca(x)
        x = self.sa(x)
        return x

class AttentionGuidedFusion(nn.Module):
    """
    Fusion of CNN features (local) and Transformer features (global).
    Concatenates, reduces dimension, applies attention gate, and residual.
    """
    def __init__(self, dim, scale_factor=1.0):
        super().__init__()
        # Assuming input dimensions are same or need resizing? 
        # Usually they are same at the skip connection level.
        self.conv_in = nn.Conv3d(dim * 2, dim, kernel_size=1, bias=False)
        self.bn_in = nn.InstanceNorm3d(dim)
        
        # Simple Attention Gate
        self.gate = nn.Sequential(
            nn.Conv3d(dim, dim // 2, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv3d(dim // 2, dim, kernel_size=1),
            nn.Sigmoid()
        )
        
        self.conv_out = nn.Sequential(
             nn.Conv3d(dim, dim, kernel_size=3, padding=1, bias=False),
             nn.InstanceNorm3d(dim),
             nn.ReLU(inplace=True)
        )

    def forward(self, cnn_feat, trans_feat):
        # inputs: [B, C, D, H, W]
        x = torch.cat([cnn_feat, trans_feat], dim=1)
        x = self.conv_in(x)
        x = self.bn_in(x)
        
        att = self.gate(x)
        x = x * att
        
        x = self.conv_out(x)
        return x + cnn_feat # Residual connection to CNN features

class CrossAttentionFusion(nn.Module):
    """
    Cross Attention Fusion: Q from CNN, K/V from Transformer
    """
    def __init__(self, dim, num_heads=4):
        super().__init__()
        self.num_heads = num_heads
        self.scale = (dim // num_heads) ** -0.5
        
        self.q_conv = nn.Conv3d(dim, dim, 1)
        self.k_conv = nn.Conv3d(dim, dim, 1)
        self.v_conv = nn.Conv3d(dim, dim, 1)
        self.proj = nn.Conv3d(dim, dim, 1)
        self.norm = nn.InstanceNorm3d(dim)
        
    def forward(self, cnn_feat, trans_feat):
        B, C, D, H, W = cnn_feat.shape
        N = D * H * W
        
        q = self.q_conv(cnn_feat).view(B, self.num_heads, C // self.num_heads, N).permute(0, 1, 3, 2)
        k = self.k_conv(trans_feat).view(B, self.num_heads, C // self.num_heads, N).permute(0, 1, 2, 3) # K^T
        v = self.v_conv(trans_feat).view(B, self.num_heads, C // self.num_heads, N).permute(0, 1, 3, 2)
        
        attn = (q @ k) * self.scale
        attn = attn.softmax(dim=-1)
        
        x = (attn @ v).permute(0, 1, 3, 2).reshape(B, C, D, H, W)
        x = self.proj(x)
        return self.norm(cnn_feat + x)

