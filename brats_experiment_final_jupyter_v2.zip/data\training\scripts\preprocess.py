import os
import glob
import SimpleITK as sitk
import argparse
from multiprocessing import Pool
from tqdm import tqdm

def n4_correction(image_path, output_path):
    if os.path.exists(output_path):
        return
        
    # Read
    img = sitk.ReadImage(image_path)
    # Convert to float
    img = sitk.Cast(img, sitk.sitkFloat32)
    
    # Mask
    mask = sitk.BinaryThreshold(img, lowerThreshold=1e-5, upperThreshold=1e10, insideValue=1, outsideValue=0)
    
    # Shrink for speed
    shrink_factor = 4
    file_spacing = img.GetSpacing()
    file_size = img.GetSize()
    
    # N4
    corrector = sitk.N4BiasFieldCorrectionImageFilter()
    # speed up parameters
    corrector.SetMaximumNumberOfIterations([50, 50, 30, 20])
    
    # Execute
    try:
        corrected = corrector.Execute(img, mask)
        sitk.WriteImage(corrected, output_path)
    except Exception as e:
        print(f"Error correcting {image_path}: {e}")

def process_case(args):
    case_dir, output_dir = args
    # BraTS usually has t1, t1ce, t2, flair. N4 helps T1/T1ce/T2/FLAIR.
    files = glob.glob(os.path.join(case_dir, "*.nii.gz"))
    for f in files:
        if "seg" in f:
            # Copy label
            out_name = os.path.join(output_dir, os.path.basename(f))
            if not os.path.exists(out_name):
                 # just copy
                 img = sitk.ReadImage(f)
                 sitk.WriteImage(img, out_name)
            continue
            
        out_name = os.path.join(output_dir, os.path.basename(f))
        n4_correction(f, out_name)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_dir", required=True, help="Path to raw data containing case folders or files")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--jobs", type=int, default=4)
    args = parser.parse_args()
    
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Flatten assumption: input_dir contains files like *_flair.nii.gz
    # OR input_dir contains subfolders per case.
    # Let's assume structure from get_brats_data: input_dir/*.nii.gz
    
    # Actually get_brats_data scans for *_flair.nii.gz in data_dir.
    # So we assume flat or single folder.
    
    files = glob.glob(os.path.join(args.input_dir, "*.nii.gz"))
    if not files:
        print("No .nii.gz files found.")
        return

    # Group by prefix
    # We can just process every non-seg file.
    
    tasks = []
    for f in files:
        out_f = os.path.join(args.output_dir, os.path.basename(f))
        if "seg" in f:
             # Just copy logic elsewhere or here?
             # Let's simple loop
             pass
        # tasks.append((f, out_f))
    
    # Actually simpler: iterate files.
    for f in tqdm(files):
        out_f = os.path.join(args.output_dir, os.path.basename(f))
        if "seg" in f:
            if not os.path.exists(out_f):
                img = sitk.ReadImage(f)
                sitk.WriteImage(img, out_f)
        else:
            n4_correction(f, out_f)
            
    print("Pre-processing complete.")

if __name__ == "__main__":
    main()
