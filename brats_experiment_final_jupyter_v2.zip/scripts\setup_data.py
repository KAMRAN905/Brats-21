import os
import tarfile
import shutil
import glob
import zipfile
import json
import subprocess
import sys

# Get the directory where this script is located (scripts/)
scripts_dir = os.path.dirname(os.path.abspath(__file__))
# exp_root is the parent of scripts/ (brats_experiment/)
exp_root = os.path.dirname(scripts_dir)
# project_root is the parent of exp_root (project/)
project_root = os.path.dirname(exp_root)

data_dir = os.path.join(exp_root, "data", "training")
os.makedirs(data_dir, exist_ok=True)

dataset_name = "dschettler8845/brats-2021-task1"
kaggle_dir = os.path.expanduser('~/.kaggle')
kaggle_json_path = os.path.join(kaggle_dir, 'kaggle.json')

def is_dataset_downloaded():
    if os.path.exists(data_dir) and len(os.listdir(data_dir)) > 0:
        return True
    return False

if not is_dataset_downloaded():
    print("Dataset not found. We will download it from Kaggle.")
    
    # Check if kaggle.json exists in ~/.kaggle/
    if not os.path.exists(kaggle_json_path):
        print("\n" + "="*50)
        print("KAGGLE DATASET DOWNLOADER")
        print("="*50)
        print("Please provide your Kaggle credentials to download the dataset.")
        print("We do NOT need the kaggle.json file. Just paste your Username and API Token Key.")
        
        # Prompt directly for username and key
        k_user = input("\nEnter your Kaggle Username: ").strip()
        k_key = input("Enter your Kaggle API Token Key: ").strip()
        
        if not k_user or not k_key:
            print("\n[ERROR] Both Username and API Token Key are required!")
            sys.exit(1)
            
        # Generate the credentials dictionary automatically
        creds = {
            "username": k_user,
            "key": k_key
        }
        
        try:
            os.makedirs(kaggle_dir, exist_ok=True)
            with open(kaggle_json_path, 'w') as f:
                json.dump(creds, f)
            try:
                os.chmod(kaggle_json_path, 0o600)
            except:
                pass
            print("\nCredentials configured successfully!")
        except Exception as e:
            print(f"\n[ERROR] Failed to set up credentials: {e}")
            sys.exit(1)
            
    print(f"\nDownloading dataset '{dataset_name}'...")
    try:
        # Download directly into exp_root
        subprocess.check_call([sys.executable, "-m", "kaggle", "datasets", "download", "-d", dataset_name, "-p", exp_root])
        print("Download complete.")
    except subprocess.CalledProcessError as e:
        print(f"\n[ERROR] Kaggle download failed. Please check if your API Token Key is correct. Error: {e}")
        sys.exit(1)

# Find specifically the brats dataset zip or tar files
tar_files = glob.glob(os.path.join(project_root, "*brats*.tar")) + glob.glob(os.path.join(exp_root, "*brats*.tar"))
zip_files = glob.glob(os.path.join(project_root, "*brats*.zip")) + glob.glob(os.path.join(exp_root, "*brats*.zip"))
all_data_files = tar_files + zip_files

if all_data_files:
    print(f"Found {len(all_data_files)} dataset files (*.tar, *.zip) in search paths.")
    for src in all_data_files:
        tf = os.path.basename(src)
        try:
            print(f"Extracting {tf} to {data_dir}...")
            if tf.lower().endswith(".zip"):
                with zipfile.ZipFile(src, "r") as zip_ref:
                    zip_ref.extractall(data_dir)
                print(f"Extracted {tf}")
            else:
                with tarfile.open(src, "r") as tar:
                    tar.extractall(path=data_dir)
                print(f"Extracted {tf}")
            
            # Remove the zip file after extraction to save space since it's 10GB!
            try:
                print(f"Cleaning up {tf} to save space...")
                os.remove(src)
            except Exception as e:
                print(f"Warning: Could not delete {src}: {e}")
                
        except Exception as e:
            print(f"Failed to extract {tf}: {e}")

# Verify extraction
print("Contents of training dir (showing top folders):")
try:
    folders = [f for f in os.listdir(data_dir) if os.path.isdir(os.path.join(data_dir, f))]
    for folder in folders[:10]:
        print(f"    {folder}/")
    if len(folders) > 10:
        print(f"    ... and {len(folders) - 10} more folders.")
except Exception as e:
    print("Could not list contents:", e)
