import random
import sys

# Robust Monkeypatch for Windows random.seed OverflowError
import traceback
original_seed = random.seed
def safe_seed(a=None, version=2):
    try:
        if a is not None:
             if isinstance(a, int):
                # Clamp to 31-bit signed integer range (0 to 2^31-1)
                a = a & 0x7FFFFFFF
        original_seed(a, version)
    except Exception as e:
        # If it still fails, use a safe constant
        original_seed(42, version)
random.seed = safe_seed

# MONAI-Specific Monkeypatch for Windows
try:
    import monai.transforms.transform
    
    _orig_set_rs = monai.transforms.transform.Randomizable.set_random_state
    
    def safe_set_random_state(self, seed=None, state=None):
        if seed is not None:
            try:
                seed = int(seed) & 0x7FFFFFFF
            except:
                seed = 42
        _orig_set_rs(self, seed, state)

    monai.transforms.transform.Randomizable.set_random_state = safe_set_random_state
except Exception as e:
    pass

import argparse
import os
import yaml
import torch
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from monai.inferers import sliding_window_inference
from monai.metrics import HausdorffDistanceMetric
from monai.transforms import Activations, AsDiscrete
from monai.data import decollate_batch
from src.dataset import get_dataloaders
from src.models import HybridSwinUNETR
from src.utils import set_seed
from tqdm import tqdm

def compute_brats_metrics(y_pred, y, spacing=None):
    # y_pred: [4, D, H, W] (One hot)
    # y: [4, D, H, W] (One hot)
    
    # TC: 1+3 (NCR + ET)
    # WT: 1+2+3 (NCR + ED + ET)
    # ET: 3 (ET)
    
    # Create Binary Masks
    # TC
    pred_tc = (y_pred[1] + y_pred[3]) > 0
    gt_tc = (y[1] + y[3]) > 0
    
    # WT
    pred_wt = (y_pred[1] + y_pred[2] + y_pred[3]) > 0
    gt_wt = (y[1] + y[2] + y[3]) > 0
    
    # ET
    pred_et = y_pred[3] > 0
    gt_et = y[3] > 0
    
    metrics = {}
    
    def dice(p, g):
        inter = (p * g).sum()
        union = p.sum() + g.sum()
        return (2 * inter / (union + 1e-5)).item()
        
    metrics['Dice_TC'] = dice(pred_tc, gt_tc)
    metrics['Dice_WT'] = dice(pred_wt, gt_wt)
    metrics['Dice_ET'] = dice(pred_et, gt_et)
    
    # HD95 (MedPy)
    # Need numpy arrays
    try:
        from medpy.metric.binary import hd95
    except ImportError:
        hd95 = None
        print("MedPy not installed. Skipping HD95.")

    def compute_hd95(p, g, spacing):
        if hd95 is None: return np.nan
        p_np = p.cpu().numpy()
        g_np = g.cpu().numpy()
        if p_np.sum() > 0 and g_np.sum() > 0:
            return hd95(p_np, g_np, voxelspacing=spacing)
        else:
            # If both empty, HD95 is 0? Or Nan? Usually 0 if perfect match (empty=empty).
            if p_np.sum() == 0 and g_np.sum() == 0:
                return 0.0
            return 373.13 # Max dist approx
            
    if spacing is not None:
        metrics['HD95_TC'] = compute_hd95(pred_tc, gt_tc, spacing)
        metrics['HD95_WT'] = compute_hd95(pred_wt, gt_wt, spacing)
        metrics['HD95_ET'] = compute_hd95(pred_et, gt_et, spacing)
    
    return metrics, (pred_tc, pred_wt, pred_et)

def perform_tta(model, inputs, roi_size):
    # Original
    out = sliding_window_inference(inputs, roi_size, 4, model)
    out = torch.softmax(out, dim=1) # [B, 4, ...]
    
    # Flip 0
    inv_0 = torch.flip(inputs, [2])
    out_0 = sliding_window_inference(inv_0, roi_size, 4, model)
    out_0 = torch.flip(torch.softmax(out_0, dim=1), [2])
    
    # Flip 1
    inv_1 = torch.flip(inputs, [3])
    out_1 = sliding_window_inference(inv_1, roi_size, 4, model)
    out_1 = torch.flip(torch.softmax(out_1, dim=1), [3])
    
    # Flip 2
    inv_2 = torch.flip(inputs, [4])
    out_2 = sliding_window_inference(inv_2, roi_size, 4, model)
    out_2 = torch.flip(torch.softmax(out_2, dim=1), [4])
    
    return (out + out_0 + out_1 + out_2) / 4.0

def evaluate(args):
    with open(args.config, 'r') as f:
        cfg = yaml.safe_load(f)
        
    device_str = cfg['project']['device']
    if device_str == 'cuda' and not torch.cuda.is_available():
        device_str = 'cpu'
    device = torch.device(device_str)
    set_seed(cfg['project']['seed'])
    
    # Data - Test set
    _, _, test_files = get_dataloaders(cfg['data']['root_dir'], cfg)
    # We manually create test loader
    from monai.data import Dataset, DataLoader
    from src.transforms import get_val_transforms
    
    test_ds = Dataset(data=test_files, transform=get_val_transforms())
    test_loader = DataLoader(test_ds, batch_size=1, shuffle=False)
    
    # Model
    # Model
    model_name = cfg['model']['name']
    if model_name == 'SwinUNETR':
        from monai.networks.nets import SwinUNETR
        model = SwinUNETR(
            img_size=tuple(cfg['data']['roi_size']),
            in_channels=cfg['model']['in_channels'],
            out_channels=cfg['model']['out_channels'],
            feature_size=cfg['model']['feature_size'],
            spatial_dims=3,
            use_checkpoint=cfg['model'].get('use_checkpoint', True)
        )
    elif model_name == 'UNet':
        from monai.networks.nets import UNet
        model = UNet(
            spatial_dims=3,
            in_channels=cfg['model']['in_channels'],
            out_channels=cfg['model']['out_channels'],
            channels=(16, 32, 64, 128, 256),
            strides=(2, 2, 2, 2)
        )
    else:
        # HybridSwinUNETR
        model = HybridSwinUNETR(
            img_size=tuple(cfg['data']['roi_size']),
            in_channels=cfg['model']['in_channels'],
            out_channels=cfg['model']['out_channels'],
            feature_size=cfg['model']['feature_size'],
            use_dual_attention=cfg['model'].get('use_dual_attention', True),
            use_fusion=cfg['model'].get('use_fusion', True),
            fusion_type=cfg['model'].get('fusion_type', 'attention_guided')
        )
    
    model = model.to(device)
    
    # Efficiency: Param Count
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Model Parameters: {total_params/1e6:.2f} M")
    
    # Load Checkpoint
    ckpt_path = os.path.join(cfg['logging']['save_dir'], cfg['project']['name'], "best_model.pth")
    if not os.path.exists(ckpt_path):
        print(f"Checkpoint not found at {ckpt_path}. Using last_model.pth or Random.")
        ckpt_path = os.path.join(cfg['logging']['save_dir'], cfg['project']['name'], "last_model.pth")
    
    if os.path.exists(ckpt_path):
        ckpt = torch.load(ckpt_path)
        model.load_state_dict(ckpt['model_state_dict'])
        print(f"Loaded checkpoint from {ckpt_path} (Epoch {ckpt['epoch']})")
    else:
        print("Running without trained weights (Demo/Test mode)")

    model.eval()
    results = []
    times = []
    
    save_fig_dir = os.path.join(cfg['logging']['save_dir'], cfg['project']['name'], "figures")
    os.makedirs(save_fig_dir, exist_ok=True)
    
    use_tta = args.tta
    
    import time
    
    with torch.no_grad():
        for i, batch in enumerate(tqdm(test_loader, desc="Evaluating")):
            inputs = batch["image"].to(device)
            labels = batch["label"].to(device)
            case_id = batch["id"][0] if "id" in batch else f"case_{i}"
            
            roi_size = tuple(cfg['data']['roi_size'])
            
            start_t = time.time()
            if use_tta:
                outputs = perform_tta(model, inputs, roi_size)
            else:
                outputs = sliding_window_inference(inputs, roi_size, 4, model)
                # Ensure softmax if not already done in model? Model returns logits.
                # Usually we want specific activation. 
                # If TTA puts softmax, we should match.
                # Logic: Model returns logits.
                # If TTA, we applied softmax per flip.
                # So if NO TTA, we should NOT apply softmax yet? 
                # Actually compute_brats_metrics expects OneHot.
                # Argmax of Logits == Argmax of Softmax.
                # So we are good with logits for argmax.
            
            torch.cuda.synchronize() if device.type == 'cuda' else None
            end_t = time.time()
            times.append(end_t - start_t)
            
            # Post process
            # Argmax
            preds = torch.argmax(outputs, dim=1) # [B, D, H, W]
            
            # One Hot
            preds_oh = torch.nn.functional.one_hot(preds.long(), num_classes=4).permute(0, 4, 1, 2, 3)
            labels_oh = torch.nn.functional.one_hot(labels.long().squeeze(1), num_classes=4).permute(0, 4, 1, 2, 3)
            
            # Metrics
            # spacing
            # We must get spacing from metadata if possible.
            # batch['image_meta_dict']['pixdim'] if exists.
            spacing = None
            if "image_meta_dict" in batch:
                # pixdim is [1, 8] usually. Spacing is indices 1,2,3?
                # Monai LoadImage returns pixdim.
                # Let's assume isotropic 1.0 if not found, since we resampled to 1.0 in val transforms.
                spacing = (1.0, 1.0, 1.0) 
            
            met, masks = compute_brats_metrics(preds_oh[0], labels_oh[0], spacing=spacing)
            met['id'] = case_id
            results.append(met)
            
            # Visuals (First 5 cases)
            if i < 5:
                # Axial slice center
                depth = inputs.shape[2] // 2
                
                fig, ax = plt.subplots(1, 3, figsize=(12, 4))
                ax[0].imshow(inputs[0, 3, depth, :, :].cpu(), cmap='gray') # FLAIR
                ax[0].set_title("FLAIR")
                
                ax[1].imshow(labels[0, 0, depth, :, :].cpu(), cmap='jet', vmin=0, vmax=3)
                ax[1].set_title("GT")
                
                ax[2].imshow(preds[0, depth, :, :].cpu(), cmap='jet', vmin=0, vmax=3)
                ax[2].set_title("Pred")
                
                plt.savefig(os.path.join(save_fig_dir, f"{case_id}.png"))
                plt.close()
                
    df = pd.DataFrame(results)
    csv_path = os.path.join(cfg['logging']['save_dir'], cfg['project']['name'], "results.csv")
    df.to_csv(csv_path, index=False)
    
    print("Results saved to", csv_path)
    print(df.describe())
    
    labels_list = ["Dice_WT", "Dice_TC", "Dice_ET", "HD95_WT", "HD95_TC", "HD95_ET"]
    summary_txt = f"Performance Summary:\nParams: {total_params/1e6:.2f} M\nAvg Inference Time: {np.mean(times):.4f} s\n"
    for l in labels_list:
        if l in df.columns:
            summary_txt += f"{l}: {df[l].mean():.4f} +/- {df[l].std():.4f}\n"
    print(summary_txt)
    with open(os.path.join(cfg['logging']['save_dir'], cfg['project']['name'], "summary.txt"), 'w') as f:
        f.write(summary_txt)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("--tta", action="store_true", help="Enable Test Time Augmentation")
    args = parser.parse_args()
    evaluate(args)
