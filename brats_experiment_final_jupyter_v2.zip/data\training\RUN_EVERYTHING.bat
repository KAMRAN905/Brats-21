@echo off
REM One-click script to run everything on Windows

cd /d "%~dp0"
echo ===================================================
echo BraTS Experiment Automation Script
echo ===================================================
echo.
echo DEBUG: Script started in "%CD%"
echo.

REM 1. Check Python
echo [Checking Python...]
python --version
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in path!
    pause
    exit /b
)

REM 2. Install Requirements
echo.
echo ===================================================
echo [1/3] Installing Dependencies...
echo (This may take a few minutes if first time)
echo ===================================================
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Failed to install dependencies.
    pause
    exit /b
)

echo.
echo [Checking Environment...]
python scripts/verify_env.py
if errorlevel 1 (
    echo [ERROR] Environment verification failed.
    pause
    exit /b
)

REM 3. Setup Data
echo.
echo ===================================================
echo [2/3] Setting up Dataset...
echo (Extracting large files - Please Wait...)
echo ===================================================
python scripts/setup_data.py
if errorlevel 1 (
    echo [ERROR] Failed to extract data.
    pause
    exit /b
)

REM 4. Run Experiments
echo.
echo ===================================================
echo [3/3] Running Experiments...
echo (Training models - Check output logs for details)
echo ===================================================
python scripts/run_experiments.py
if errorlevel 1 (
    echo [ERROR] Experiments failed or interrupted.
    pause
    exit /b
)

echo.
echo ===================================================
echo All Done! Results are in the 'outputs' folder.
echo ===================================================
pause
