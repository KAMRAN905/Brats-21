import torch
import torch.nn as nn
from monai.networks.nets import SwinUNETR, resnet50
from monai.networks.blocks import UnetBasicBlock, UnetOutBlock, UnetResBlock, Convolution
from monai.utils import ensure_tuple_rep
from src.modules import DualAttentionModule, AttentionGuidedFusion, CrossAttentionFusion

class CNNEncoder(nn.Module):
    def __init__(self, spatial_dims, in_channels, base_filters=16):
        super().__init__()
        # Use MONAI's ResNet50
        self.resnet = resnet50(spatial_dims=spatial_dims, n_input_channels=in_channels, num_classes=1)
        # Custom conv0 to preserve 128x128x128 spatial resolution (Swin enc0 matches input resolution)
        self.conv0 = Convolution(spatial_dims=spatial_dims, in_channels=in_channels, out_channels=64, strides=1, kernel_size=3, padding=1)

    def forward(self, x):
        # x: 128
        x0 = self.conv0(x) # 128
        x1 = self.resnet.conv1(x) # 64
        x1 = self.resnet.bn1(x1)
        x1 = self.resnet.act(x1)
        
        x2 = self.resnet.maxpool(x1)
        x2 = self.resnet.layer1(x2) # 32
        
        x3 = self.resnet.layer2(x2) # 16
        x4 = self.resnet.layer3(x3) # 8
        
        # We drop layer4 (4x4x4) because SwinUNETR only goes down to 8x8x8 for feature fusion
        
        return [x0, x1, x2, x3, x4]

class HybridSwinUNETR(nn.Module):
    def __init__(self, 
                 img_size, 
                 in_channels, 
                 out_channels, 
                 feature_size=48, 
                 use_dual_attention=True, 
                 use_fusion=True,
                 fusion_type='attention_guided'):
        super().__init__()
        # Use SwinUNETR as the Transformer Backbone reference
        # We will use its SwinViT backbone or just instantiate a SwinUNETR and use its attributes if possible.
        # However, to be cleaner, we'll instantiate SwinUNETR and ignore its decoder, or create a fresh architecture.
        # Let's instantiate SwinUNETR to get the encoder.
        self.swin_model = SwinUNETR(
            img_size=img_size,
            in_channels=in_channels,
            out_channels=out_channels,
            feature_size=feature_size,
            use_checkpoint=True,
            spatial_dims=3
        )
        self.swinViT = self.swin_model.swinViT
        self.encoder1 = self.swin_model.encoder1
        self.encoder2 = self.swin_model.encoder2
        self.encoder3 = self.swin_model.encoder3
        self.encoder4 = self.swin_model.encoder4
        self.encoder10 = self.swin_model.encoder10 # Bottleneck
        
        # Parallel CNN Encoder
        # Feature sizes in SwinUNETR: 
        # Enc1: 48 (input resolution) -> No, features are different.
        # SwinUNETR skips: 0 (embed), 1, 2, 3, 4(bottleneck)
        # We need CNN to match these dimensions or project them.
        self.cnn_encoder = CNNEncoder(3, in_channels, base_filters=feature_size // 2) 
        # Adjust base_filters to match rough capacity or just project.
        
        self.use_dual_attention = use_dual_attention
        self.use_fusion = use_fusion
        
        # Projections to match dimensions for Fusion
        # Swin feature sizes: C * 2^i usually.
        # C=48.
        # s0: C=48
        # s1: 2C=96
        # s2: 4C=192
        # s3: 8C=384
        # s4: 16C=768 (Bottleneck)
        
        # CNN (base=24):
        # c1: 24
        # c2: 48
        # c3: 96
        # c4: 192
        # c5: 384
        
        # Projections to match dimensions for Fusion
        # Swin feature sizes: C * 2^i usually.
        self.dims = [feature_size * (2**i) for i in range(5)]
        
        # CNN (base=24):
        # c1: 24
        # c2: 48
        # c3: 96
        # c4: 192
        # c5: 384
        
        # Projections to match dimensions for Fusion
        self.projections = nn.ModuleList()
        self.da_blocks = nn.ModuleList()
        self.fusion_blocks = nn.ModuleList()
        
        # ResNet50 channels corresponding to [x0, x1, x2, x3, x4]
        cnn_channels = [64, 64, 256, 512, 1024]
        
        for i, d in enumerate(self.dims):
            cnn_ch = cnn_channels[i]
            # Projection if needed
            if cnn_ch != d:
                self.projections.append(nn.Conv3d(cnn_ch, d, kernel_size=1))
            else:
                self.projections.append(nn.Identity())
            
            # Dual Attention
            if use_dual_attention:
                self.da_blocks.append(DualAttentionModule(d)) 
            else:
                self.da_blocks.append(nn.Identity())
            
            # Fusion
            if use_fusion:
                if fusion_type == 'cross_attention':
                    self.fusion_blocks.append(CrossAttentionFusion(d))
                else:
                    self.fusion_blocks.append(AttentionGuidedFusion(d))
            else:
                self.fusion_blocks.append(nn.Identity())

        # Decoder ... (rest matches previous)
        self.decoder5 = Convolution(spatial_dims=3, in_channels=self.dims[4], out_channels=self.dims[3], strides=1, kernel_size=3) 
        self.decoder4 = Convolution(spatial_dims=3, in_channels=self.dims[4] + self.dims[3], out_channels=self.dims[3], strides=1, kernel_size=3)
        self.upsample = nn.Upsample(scale_factor=2, mode='trilinear', align_corners=True)
        
        self.decoder3 = Convolution(spatial_dims=3, in_channels=self.dims[3] + self.dims[2], out_channels=self.dims[2], strides=1, kernel_size=3)
        self.decoder2 = Convolution(spatial_dims=3, in_channels=self.dims[2] + self.dims[1], out_channels=self.dims[1], strides=1, kernel_size=3)
        self.decoder1 = Convolution(spatial_dims=3, in_channels=self.dims[1] + self.dims[0], out_channels=self.dims[0], strides=1, kernel_size=3)
        
        self.out = UnetOutBlock(3, self.dims[0], out_channels)


    def forward(self, x_in):
        # Swin Path (Encoder)
        hidden_states_out = self.swinViT(x_in, self.swin_model.normalize)
        enc0 = self.encoder1(x_in)
        enc1 = self.encoder2(hidden_states_out[0])
        enc2 = self.encoder3(hidden_states_out[1])
        enc3 = self.encoder4(hidden_states_out[2])
        enc4 = self.encoder10(hidden_states_out[4])
        
        swin_feats = [enc0, enc1, enc2, enc3, enc4]
        
        # CNN Path
        cnn_feats = self.cnn_encoder(x_in)
        
        # Dual Attention & Fusion
        fused_feats = []
        for i in range(5):
            t_f = swin_feats[i]
            c_f = cnn_feats[i]
            
            # Match dimensions
            c_f = self.projections[i](c_f)

            # Apply DA to CNN 
            if self.use_dual_attention:
                c_f = self.da_blocks[i](c_f)
                
            # Fusion
            if self.use_fusion:
                # Our fusion module takes (cnn, trans)
                f_f = self.fusion_blocks[i](c_f, t_f)
            else:
                f_f = c_f + t_f # Simple sum default if no fusion module but fusion is False?
                # Actually if fusion=False, maybe keep CNN or Swin?
                # Ablation says "remove fusion" -> "Backbone + DA only".
                # If we remove fusion, valid question: how do we combine?
                # User's ablation E5 (No fusion?) -> "Backbone + DA only":
                # Wait, usually ablation means disable the "Advanced Fusion" and use simple concat/sum.
                f_f = t_f # Fallback to Swin (Backbone) only? Or CNN?
                # "Backbone + DA" implies we keep the Hybrid but use simple sum?
                # Let's assume simple sum or "Backbone only" means just Swin.
                # But we want to test DA.
                # Let's define: No Fusion Module = Simple Sum or Concatenation.
                f_f = c_f + t_f
            
            fused_feats.append(f_f)
            
        # Decoder
        # f0, f1, f2, f3, f4 (Bottleneck)
        
        # Bottleneck
        bot = fused_feats[4]
        
        # Up 4
        # up(bot) + f3
        # We need to reshape/up
        # Using simple upsample
        up4 = self.upsample(bot)
        cat4 = torch.cat([fused_feats[3], up4], dim=1)
        dec4 = self.decoder4(cat4)
        
        up3 = self.upsample(dec4)
        cat3 = torch.cat([fused_feats[2], up3], dim=1)
        dec3 = self.decoder3(cat3)
        
        up2 = self.upsample(dec3)
        cat2 = torch.cat([fused_feats[1], up2], dim=1)
        dec2 = self.decoder2(cat2)
        
        up1 = self.upsample(dec2)
        cat1 = torch.cat([fused_feats[0], up1], dim=1)
        dec1 = self.decoder1(cat1)
        
        logits = self.out(dec1)
        return logits

